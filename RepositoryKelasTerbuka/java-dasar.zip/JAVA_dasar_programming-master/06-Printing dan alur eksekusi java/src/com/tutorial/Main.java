package com.tutorial;

public class Main {

    public static void main(String[] args){

        System.out.println("hello teman-teman");
        System.out.println("baris ke-2 : hai juga akang pukis");

        System.out.print("baris ke-3 : ini adalah baris ketiga");
        System.out.print("baris ke-4 : saya meneruskan baris ketiga");

        System.out.print("baris ke-5 : hallo mahmuy???");
        System.out.println("baris ke-6 : hallo juga hobloh!!!");

        System.out.print("baris ke-7 : hai bro, mari kita kongkow \n");
        System.out.print("baris ke-8 : kongkow kemana bro? \n");
        System.out.print("baris ke-9 : mari kita kongkow ke citamiang!!!\n");

        System.out.printf("wiro sableng naga geni %d", 212);


    }
}
