package com.tutorial;

public class Main {

    public static void main(String[] args){

        // kita akan membuat variabel
        // tipe data
        int a = 10; // assignment
        System.out.println("nilai a = " + a);

        a = 20;
        System.out.println("nilai a baru = " + a);

        // kita akan membuat sebuah deklarasi
        int b; // deklarasi

        b = 7;

        System.out.println("nilai b = " + b);


    }
}
