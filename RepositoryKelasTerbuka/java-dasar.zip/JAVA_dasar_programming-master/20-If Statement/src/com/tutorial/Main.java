package com.tutorial;

public class Main {


    public static void main (String[] args){

//        tutorial untuk if statement atau percabangan

        int a = 5;

        System.out.println("nilai = " + a);

        // ini adalah cabangnya

        if (a == 10){

            System.out.println("ini adalah jalur true");

        } else {

            System.out.println("ini adalah jalur false");

        }


        System.out.println("selesai");

    }
}
