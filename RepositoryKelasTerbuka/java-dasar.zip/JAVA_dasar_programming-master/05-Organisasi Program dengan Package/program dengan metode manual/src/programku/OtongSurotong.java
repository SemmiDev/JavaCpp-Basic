package programku;


public class OtongSurotong {

	public static void main(String[] args){

		System.out.print("Nama ku adalah Otong, teman si ucup");

	}
}